"""da
Cosmic Vanguard - Space Shooter Arcade (Vertical Scrolling)
Implementado conforme GDD 1.

ASSETS:
Coloque os arquivos PNG na pasta assets/ com estes nomes exatos.
Se um arquivo não existir, o jogo desenha um placeholder colorido
no lugar (retângulo/círculo), então ele SEMPRE roda, mesmo sem os PNGs.

    assets/
        player.png          (48x48) - nave do jogador
        enemy_scout.png      (40x40) - inimigo básico
        enemy_interceptor.png(36x36) - inimigo rápido
        enemy_cruiser.png    (56x56) - inimigo tanque
        bullet_player.png    (8x16)  - tiro do jogador
        bullet_enemy.png     (8x16)  - tiro inimigo
        powerup_double.png   (24x24) - power-up tiro duplo (ícone azul)
        powerup_shield.png   (24x24) - power-up escudo (ícone verde)
        powerup_repair.png   (24x24) - power-up reparo (ícone vermelho)
        star_bg_far.png      (2x2)   - estrela camada distante (opcional, senão desenha pixel)
        star_bg_near.png     (3x3)   - estrela camada próxima (opcional)
        explosion_0.png .. explosion_4.png (48x48) - 5 frames de explosão

Recomendo o pacote "Space Shooter Redux" ou "Simple Space" da Kenney.nl
(licença CC0, gratuita) - renomeie os arquivos baixados para os nomes acima.

Como rodar:
    pip install pygame
    python main.py
"""

import os
import sys
import math
import random
import pygame

# ---------------------------------------------------------------------------
# CONFIGURAÇÃO GERAL
# ---------------------------------------------------------------------------

SCREEN_W, SCREEN_H = 480, 720
FPS = 60

ASSET_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")

BLACK = (5, 6, 15)
WHITE = (240, 240, 245)
RED = (220, 60, 60)
GREEN = (70, 200, 120)
BLUE = (70, 140, 230)
YELLOW = (240, 210, 80)
GRAY = (120, 120, 130)

# ---------------------------------------------------------------------------
# CARREGAMENTO DE ASSETS COM FALLBACK
# ---------------------------------------------------------------------------


def load_image(filename, size, fallback_draw):
    """Carrega uma imagem de assets/. Se não existir, gera um placeholder
    desenhado via fallback_draw(surface, size) -> None."""
    path = os.path.join(ASSET_DIR, filename)
    surf = pygame.Surface(size, pygame.SRCALPHA)
    if os.path.isfile(path):
        try:
            img = pygame.image.load(path).convert_alpha()
            return pygame.transform.smoothscale(img, size)
        except Exception as e:
            print(f"[aviso] Falha ao carregar {filename}: {e}. Usando placeholder.")
    fallback_draw(surf, size)
    return surf


def _fb_player(surf, size):
    w, h = size
    pygame.draw.polygon(surf, BLUE, [(w // 2, 0), (0, h), (w, h)])
    pygame.draw.polygon(surf, WHITE, [(w // 2, h * 0.15), (w * 0.25, h * 0.8), (w * 0.75, h * 0.8)], 2)


def _fb_enemy(color):
    def draw(surf, size):
        w, h = size
        pygame.draw.polygon(surf, color, [(0, 0), (w, 0), (w // 2, h)])
        pygame.draw.circle(surf, WHITE, (w // 2, h // 3), max(2, w // 8), 1)
    return draw


def _fb_bullet(color):
    def draw(surf, size):
        w, h = size
        pygame.draw.rect(surf, color, (0, 0, w, h), border_radius=w // 2)
    return draw


def _fb_powerup(color):
    def draw(surf, size):
        w, h = size
        pygame.draw.circle(surf, color, (w // 2, h // 2), w // 2)
        pygame.draw.circle(surf, WHITE, (w // 2, h // 2), w // 2, 2)
    return draw


def _fb_explosion(frame_index):
    def draw(surf, size):
        w, h = size
        r = int((frame_index + 1) / 5 * (w // 2))
        colors = [YELLOW, (240, 160, 60), (230, 100, 50), (180, 60, 40), (90, 30, 30)]
        pygame.draw.circle(surf, colors[frame_index], (w // 2, h // 2), max(1, r))
    return draw


class Assets:
    """Carrega (ou gera placeholders para) todos os sprites do jogo uma vez."""

    def __init__(self):
        self.player = load_image("player.png", (48, 48), _fb_player)
        self.enemy_scout = load_image("enemy_scout.png", (40, 40), _fb_enemy((200, 90, 90)))
        self.enemy_interceptor = load_image(
            "enemy_interceptor.png", (36, 36), _fb_enemy((230, 170, 60))
        )
        self.enemy_cruiser = load_image(
            "enemy_cruiser.png", (56, 56), _fb_enemy((160, 90, 200))
        )
        self.bullet_player = load_image("bullet_player.png", (8, 16), _fb_bullet(YELLOW))
        self.bullet_enemy = load_image("bullet_enemy.png", (8, 16), _fb_bullet(RED))
        self.powerup_double = load_image("powerup_double.png", (24, 24), _fb_powerup(BLUE))
        self.powerup_shield = load_image("powerup_shield.png", (24, 24), _fb_powerup(GREEN))
        self.powerup_repair = load_image("powerup_repair.png", (24, 24), _fb_powerup(RED))
        self.explosion_frames = [
            load_image(f"explosion_{i}.png", (48, 48), _fb_explosion(i)) for i in range(5)
        ]


# ---------------------------------------------------------------------------
# ENTIDADES
# ---------------------------------------------------------------------------


class Starfield:
    """Fundo estelar parallax com duas camadas (GDD 5)."""

    def __init__(self):
        self.far = [
            [random.randint(0, SCREEN_W), random.randint(0, SCREEN_H), random.uniform(1, 1.5)]
            for _ in range(60)
        ]
        self.near = [
            [random.randint(0, SCREEN_W), random.randint(0, SCREEN_H), random.uniform(1.5, 2.2)]
            for _ in range(30)
        ]

    def update(self, dt, speed_mult):
        for layer, base_speed in ((self.far, 40), (self.near, 90)):
            for star in layer:
                star[1] += base_speed * star[2] * speed_mult * dt
                if star[1] > SCREEN_H:
                    star[1] = 0
                    star[0] = random.randint(0, SCREEN_W)

    def draw(self, surf):
        for star in self.far:
            pygame.draw.circle(surf, (110, 110, 130), (int(star[0]), int(star[1])), 1)
        for star in self.near:
            pygame.draw.circle(surf, (200, 200, 220), (int(star[0]), int(star[1])), 2)


class Particle:
    """Partícula simples de propulsão."""

    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.vy = random.uniform(80, 160)
        self.vx = random.uniform(-20, 20)
        self.life = random.uniform(0.15, 0.35)
        self.age = 0.0
        self.size = random.randint(2, 4)

    def update(self, dt):
        self.age += dt
        self.x += self.vx * dt
        self.y += self.vy * dt
        return self.age < self.life

    def draw(self, surf):
        t = 1 - (self.age / self.life)
        color = (255, int(180 * t) + 40, 40)
        pygame.draw.circle(surf, color, (int(self.x), int(self.y)), max(1, int(self.size * t)))


class Explosion(pygame.sprite.Sprite):
    FRAME_TIME = 0.1

    def __init__(self, assets, center):
        super().__init__()
        self.assets = assets
        self.frame = 0
        self.timer = 0.0
        self.image = self.assets.explosion_frames[0]
        self.rect = self.image.get_rect(center=center)

    def update(self, dt):
        self.timer += dt
        if self.timer >= self.FRAME_TIME:
            self.timer = 0.0
            self.frame += 1
            if self.frame >= len(self.assets.explosion_frames):
                self.kill()
                return
            center = self.rect.center
            self.image = self.assets.explosion_frames[self.frame]
            self.rect = self.image.get_rect(center=center)


class Bullet(pygame.sprite.Sprite):
    def __init__(self, image, pos, velocity, damage, from_player):
        super().__init__()
        self.image = image
        self.rect = self.image.get_rect(center=pos)
        self.pos = pygame.math.Vector2(pos)
        self.velocity = pygame.math.Vector2(velocity)
        self.damage = damage
        self.from_player = from_player

    def update(self, dt):
        self.pos += self.velocity * dt
        self.rect.center = (round(self.pos.x), round(self.pos.y))
        if self.rect.bottom < -20 or self.rect.top > SCREEN_H + 20:
            self.kill()


class PowerUp(pygame.sprite.Sprite):
    SPEED = 100

    def __init__(self, image, pos, kind):
        super().__init__()
        self.image = image
        self.rect = self.image.get_rect(center=pos)
        self.kind = kind  # "double", "shield", "repair"
        self.y = float(pos[1])

    def update(self, dt):
        self.y += self.SPEED * dt
        self.rect.centery = round(self.y)
        if self.rect.top > SCREEN_H:
            self.kill()


class Player(pygame.sprite.Sprite):
    SPEED = 300
    MAX_HP = 5
    FIRE_COOLDOWN = 0.25
    INVULN_TIME = 1.5

    def __init__(self, assets, game):
        super().__init__()
        self.assets = assets
        self.game = game
        self.base_image = assets.player
        self.image = self.base_image
        self.rect = self.image.get_rect(center=(SCREEN_W // 2, SCREEN_H - 100))
        self.pos = pygame.math.Vector2(self.rect.center)

        self.hp = self.MAX_HP
        self.shield = False
        self.fire_timer = 0.0
        self.invuln_timer = 0.0
        self.double_shot_timer = 0.0
        self.visible = True
        self.blink_timer = 0.0
        self.particle_timer = 0.0

    @property
    def alive_state(self):
        return self.hp > 0

    def handle_input(self, dt, keys):
        direction = pygame.math.Vector2(0, 0)
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            direction.x -= 1
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            direction.x += 1
        if keys[pygame.K_UP] or keys[pygame.K_w]:
            direction.y -= 1
        if keys[pygame.K_DOWN] or keys[pygame.K_s]:
            direction.y += 1
        if direction.length_squared() > 0:
            direction = direction.normalize()
        self.pos += direction * self.SPEED * dt
        self.rect.center = (round(self.pos.x), round(self.pos.y))
        self.rect.clamp_ip(pygame.Rect(0, 0, SCREEN_W, SCREEN_H))
        self.pos.update(self.rect.center)

        # propulsão (partículas)
        if direction.length_squared() > 0:
            self.particle_timer -= dt
            if self.particle_timer <= 0:
                self.particle_timer = 0.03
                self.game.particles.append(
                    Particle(self.rect.centerx + random.uniform(-6, 6), self.rect.bottom - 4)
                )

        firing = keys[pygame.K_SPACE] or pygame.mouse.get_pressed()[0]
        self.fire_timer -= dt
        if firing and self.fire_timer <= 0:
            self.fire_timer = self.FIRE_COOLDOWN
            self.shoot()

    def shoot(self):
        top = (self.rect.centerx, self.rect.top)
        if self.double_shot_timer > 0:
            offsets = [-10, 10]
        else:
            offsets = [0]
        for off in offsets:
            pos = (top[0] + off, top[1])
            b = Bullet(self.assets.bullet_player, pos, (0, -600), 1, from_player=True)
            self.game.player_bullets.add(b)
            self.game.all_sprites.add(b)

    def take_damage(self, amount=1):
        if self.invuln_timer > 0:
            return
        if self.shield:
            self.shield = False
            self.invuln_timer = self.INVULN_TIME
            return
        self.hp -= amount
        self.invuln_timer = self.INVULN_TIME
        if self.hp <= 0:
            self.hp = 0
            self.game.on_player_death()

    def apply_powerup(self, kind):
        if kind == "double":
            self.double_shot_timer = 8.0
        elif kind == "shield":
            self.shield = True
        elif kind == "repair":
            self.hp = min(self.MAX_HP, self.hp + 1)

    def update(self, dt, keys):
        if self.invuln_timer > 0:
            self.invuln_timer -= dt
            self.blink_timer -= dt
            if self.blink_timer <= 0:
                self.blink_timer = 0.1
                self.visible = not self.visible
        else:
            self.visible = True

        if self.double_shot_timer > 0:
            self.double_shot_timer -= dt

        self.handle_input(dt, keys)

    def draw(self, surf):
        if self.visible:
            surf.blit(self.base_image, self.rect)
        if self.shield:
            pygame.draw.circle(surf, GREEN, self.rect.center, self.rect.width // 2 + 6, 2)


class Enemy(pygame.sprite.Sprite):
    """Classe base para os 3 tipos de inimigo (GDD 4.2)."""

    TYPE_DATA = {
        "scout": dict(hp=1, speed=200, points=100, shoots=False),
        "interceptor": dict(hp=1, speed=350, points=200, shoots=False),
        "cruiser": dict(hp=5, speed=80, points=500, shoots=True),
    }

    def __init__(self, assets, game, kind, x, difficulty_mult=1.0):
        super().__init__()
        self.assets = assets
        self.game = game
        self.kind = kind
        data = self.TYPE_DATA[kind]
        self.hp = data["hp"]
        self.speed = data["speed"] * difficulty_mult
        self.points = data["points"]
        self.shoots = data["shoots"]

        image_map = {
            "scout": assets.enemy_scout,
            "interceptor": assets.enemy_interceptor,
            "cruiser": assets.enemy_cruiser,
        }
        self.image = image_map[kind]
        self.rect = self.image.get_rect(center=(x, -40))
        self.pos = pygame.math.Vector2(self.rect.center)

        self.spawn_time = 0.0
        self.shoot_timer = random.uniform(0.5, 2.0)

    def update(self, dt):
        self.spawn_time += dt
        if self.kind == "interceptor":
            # movimento senoidal em X
            self.pos.x += math.sin(self.spawn_time * 4) * 120 * dt
            self.pos.y += self.speed * dt
        else:
            self.pos.y += self.speed * dt

        self.rect.center = (round(self.pos.x), round(self.pos.y))

        if self.shoots:
            self.shoot_timer -= dt
            if self.shoot_timer <= 0:
                self.shoot_timer = 2.0
                b = Bullet(
                    self.assets.bullet_enemy,
                    (self.rect.centerx, self.rect.bottom),
                    (0, 220),
                    1,
                    from_player=False,
                )
                self.game.enemy_bullets.add(b)
                self.game.all_sprites.add(b)

        if self.rect.top > SCREEN_H + 40:
            self.kill()

    def take_damage(self, amount):
        self.hp -= amount
        return self.hp <= 0


class EnemySpawner:
    """Controla o spawn e a curva de dificuldade (GDD 4.4)."""

    WEIGHTS = [("scout", 0.60), ("interceptor", 0.25), ("cruiser", 0.15)]

    def __init__(self, game):
        self.game = game
        self.elapsed = 0.0
        self.spawn_interval = 1.1
        self.spawn_timer = self.spawn_interval
        self.difficulty_mult = 1.0

    def _pick_kind(self):
        r = random.random()
        cumulative = 0.0
        for kind, w in self.WEIGHTS:
            cumulative += w
            if r <= cumulative:
                return kind
        return self.WEIGHTS[-1][0]

    def update(self, dt):
        self.elapsed += dt
        # a cada 30s: spawn -10%, velocidade +5%
        steps = int(self.elapsed // 30)
        self.spawn_interval = max(0.35, 1.1 * (0.9 ** steps))
        self.difficulty_mult = 1.05 ** steps

        self.spawn_timer -= dt
        if self.spawn_timer <= 0:
            self.spawn_timer = self.spawn_interval
            kind = self._pick_kind()
            x = random.randint(40, SCREEN_W - 40)
            enemy = Enemy(self.game.assets, self.game, kind, x, self.difficulty_mult)
            self.game.enemies.add(enemy)
            self.game.all_sprites.add(enemy)


# ---------------------------------------------------------------------------
# JOGO
# ---------------------------------------------------------------------------


class Game:
    STATE_MENU = "MENU"
    STATE_PLAYING = "PLAYING"
    STATE_PAUSED = "PAUSED"
    STATE_GAMEOVER = "GAMEOVER"

    def __init__(self):
        pygame.init()
        pygame.display.set_caption("Cosmic Vanguard")
        self.screen = pygame.display.set_mode((SCREEN_W, SCREEN_H))
        self.clock = pygame.time.Clock()
        self.assets = Assets()
        self.font_small = pygame.font.SysFont("consolas", 18)
        self.font_med = pygame.font.SysFont("consolas", 28, bold=True)
        self.font_big = pygame.font.SysFont("consolas", 48, bold=True)

        self.high_score = self._load_high_score()
        self.state = self.STATE_MENU
        self.starfield = Starfield()
        self.reset_run()

    def _load_high_score(self):
        path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "highscore.txt")
        if os.path.isfile(path):
            try:
                with open(path, "r") as f:
                    return int(f.read().strip())
            except Exception:
                return 0
        return 0

    def _save_high_score(self):
        path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "highscore.txt")
        try:
            with open(path, "w") as f:
                f.write(str(self.high_score))
        except Exception:
            pass

    def reset_run(self):
        self.all_sprites = pygame.sprite.Group()
        self.enemies = pygame.sprite.Group()
        self.player_bullets = pygame.sprite.Group()
        self.enemy_bullets = pygame.sprite.Group()
        self.powerups = pygame.sprite.Group()
        self.explosions = pygame.sprite.Group()
        self.particles = []

        self.player = Player(self.assets, self)
        self.all_sprites.add(self.player)
        self.spawner = EnemySpawner(self)

        self.score = 0
        self.survival_time = 0.0

    # -- eventos de jogo -----------------------------------------------
    def on_player_death(self):
        self.state = self.STATE_GAMEOVER
        if self.score > self.high_score:
            self.high_score = self.score
            self._save_high_score()

    def on_enemy_killed(self, enemy):
        self.score += enemy.points
        self.explosions.add(Explosion(self.assets, enemy.rect.center))
        if random.random() < 0.15:
            kind = random.choice(["double", "shield", "repair"])
            image_map = {
                "double": self.assets.powerup_double,
                "shield": self.assets.powerup_shield,
                "repair": self.assets.powerup_repair,
            }
            p = PowerUp(image_map[kind], enemy.rect.center, kind)
            self.powerups.add(p)
            self.all_sprites.add(p)

    # -- loop principal ---------------------------------------------------
    def run(self):
        while True:
            dt = self.clock.tick(FPS) / 1000.0
            dt = min(dt, 1 / 30)  # evita saltos grandes
            self.handle_events()
            if self.state == self.STATE_PLAYING:
                self.update(dt)
            self.draw()
            pygame.display.flip()

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_p, pygame.K_ESCAPE):
                    if self.state == self.STATE_PLAYING:
                        self.state = self.STATE_PAUSED
                    elif self.state == self.STATE_PAUSED:
                        self.state = self.STATE_PLAYING
                if event.key == pygame.K_RETURN:
                    if self.state == self.STATE_MENU:
                        self.reset_run()
                        self.state = self.STATE_PLAYING
                    elif self.state == self.STATE_GAMEOVER:
                        self.reset_run()
                        self.state = self.STATE_PLAYING

    def update(self, dt):
        self.survival_time += dt
        self.score += int(10 * dt)  # +10 pts/segundo de sobrevivência

        keys = pygame.key.get_pressed()
        speed_mult = 1.0 + self.spawner.difficulty_mult * 0.2
        self.starfield.update(dt, speed_mult)

        self.player.update(dt, keys)
        self.spawner.update(dt)
        self.enemies.update(dt)
        self.player_bullets.update(dt)
        self.enemy_bullets.update(dt)
        self.powerups.update(dt)
        self.explosions.update(dt)

        self.particles = [p for p in self.particles if p.update(dt)]

        self._handle_collisions()

    def _handle_collisions(self):
        # tiro do jogador atinge inimigo
        hits = pygame.sprite.groupcollide(self.enemies, self.player_bullets, False, True)
        for enemy, bullets in hits.items():
            dead = enemy.take_damage(sum(b.damage for b in bullets))
            if dead:
                enemy.kill()
                self.on_enemy_killed(enemy)

        # inimigo colide com jogador
        if self.player.alive_state:
            collided = pygame.sprite.spritecollide(self.player, self.enemies, True)
            for enemy in collided:
                self.explosions.add(Explosion(self.assets, enemy.rect.center))
                self.player.take_damage(1)

            # tiro inimigo atinge jogador
            hit_bullets = pygame.sprite.spritecollide(self.player, self.enemy_bullets, True)
            if hit_bullets:
                self.player.take_damage(1)

            # jogador coleta power-up
            collected = pygame.sprite.spritecollide(self.player, self.powerups, True)
            for p in collected:
                self.player.apply_powerup(p.kind)

    # -- desenho ------------------------------------------------------
    def draw(self):
        self.screen.fill(BLACK)
        self.starfield.draw(self.screen)

        if self.state == self.STATE_MENU:
            self.draw_menu()
        else:
            self.draw_playfield()
            if self.state == self.STATE_PAUSED:
                self.draw_pause_overlay()
            elif self.state == self.STATE_GAMEOVER:
                self.draw_gameover_overlay()

    def draw_playfield(self):
        for p in self.particles:
            p.draw(self.screen)

        for enemy in self.enemies:
            self.screen.blit(enemy.image, enemy.rect)
        for b in self.player_bullets:
            self.screen.blit(b.image, b.rect)
        for b in self.enemy_bullets:
            self.screen.blit(b.image, b.rect)
        for p in self.powerups:
            self.screen.blit(p.image, p.rect)
        for e in self.explosions:
            self.screen.blit(e.image, e.rect)

        if self.player.alive_state:
            self.player.draw(self.screen)

        self.draw_hud()

    def draw_hud(self):
        # corações de HP
        for i in range(Player.MAX_HP):
            color = RED if i < self.player.hp else (60, 60, 65)
            cx = 24 + i * 26
            cy = 24
            pygame.draw.circle(self.screen, color, (cx - 5, cy), 7)
            pygame.draw.circle(self.screen, color, (cx + 5, cy), 7)
            pygame.draw.polygon(self.screen, color, [(cx - 11, cy + 2), (cx + 11, cy + 2), (cx, cy + 14)])

        if self.player.shield:
            txt = self.font_small.render("ESCUDO: ATIVO", True, GREEN)
            self.screen.blit(txt, (20, 44))

        score_txt = self.font_med.render(f"{self.score:06d}", True, WHITE)
        self.screen.blit(score_txt, (SCREEN_W - score_txt.get_width() - 16, 14))
        high_txt = self.font_small.render(f"HIGH: {self.high_score:06d}", True, GRAY)
        self.screen.blit(high_txt, (SCREEN_W - high_txt.get_width() - 16, 44))

    def draw_menu(self):
        title = self.font_big.render("COSMIC VANGUARD", True, WHITE)
        self.screen.blit(title, (SCREEN_W // 2 - title.get_width() // 2, 220))
        sub = self.font_small.render("Setas/WASD move · Espaço atira · P pausa", True, GRAY)
        self.screen.blit(sub, (SCREEN_W // 2 - sub.get_width() // 2, 290))
        prompt = self.font_med.render("ENTER para começar", True, YELLOW)
        self.screen.blit(prompt, (SCREEN_W // 2 - prompt.get_width() // 2, 400))
        high_txt = self.font_small.render(f"High Score: {self.high_score}", True, GRAY)
        self.screen.blit(high_txt, (SCREEN_W // 2 - high_txt.get_width() // 2, 450))

    def draw_pause_overlay(self):
        overlay = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 150))
        self.screen.blit(overlay, (0, 0))
        txt = self.font_big.render("PAUSADO", True, WHITE)
        self.screen.blit(txt, (SCREEN_W // 2 - txt.get_width() // 2, SCREEN_H // 2 - 24))

    def draw_gameover_overlay(self):
        overlay = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        self.screen.blit(overlay, (0, 0))
        txt = self.font_big.render("GAME OVER", True, RED)
        self.screen.blit(txt, (SCREEN_W // 2 - txt.get_width() // 2, 260))
        score_txt = self.font_med.render(f"Pontuação: {self.score}", True, WHITE)
        self.screen.blit(score_txt, (SCREEN_W // 2 - score_txt.get_width() // 2, 320))
        prompt = self.font_small.render("ENTER para jogar novamente", True, YELLOW)
        self.screen.blit(prompt, (SCREEN_W // 2 - prompt.get_width() // 2, 380))


if __name__ == "__main__":
    Game().run()
