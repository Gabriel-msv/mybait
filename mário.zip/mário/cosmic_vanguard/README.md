# Cosmic Vanguard

Space shooter arcade vertical (GDD 1), em Python + Pygame.

## Como rodar

```bash
pip install pygame
python main.py
```

## Controles

- **WASD / Setas**: mover a nave
- **Espaço** ou **clique esquerdo**: atirar
- **P / Esc**: pausar
- **Enter**: iniciar / reiniciar

## Imagens (assets/)

O jogo **já roda sem nenhuma imagem** — sem PNGs na pasta `assets/`, ele
desenha placeholders coloridos (triângulos, círculos) no lugar de cada
sprite, então dá pra testar tudo imediatamente.

Para usar sprites de verdade, baixe um pacote de bancos de imagem
gratuitos (ex: **Kenney.nl** → "Space Shooter Redux" ou "Simple Space",
licença CC0) e coloque os arquivos em `assets/` **com estes nomes exatos**:

| Arquivo | Tamanho sugerido | Uso |
|---|---|---|
| `player.png` | 48x48 | nave do jogador |
| `enemy_scout.png` | 40x40 | inimigo básico |
| `enemy_interceptor.png` | 36x36 | inimigo rápido (zigue-zague) |
| `enemy_cruiser.png` | 56x56 | inimigo tanque |
| `bullet_player.png` | 8x16 | tiro do jogador |
| `bullet_enemy.png` | 8x16 | tiro inimigo |
| `powerup_double.png` | 24x24 | power-up tiro duplo |
| `powerup_shield.png` | 24x24 | power-up escudo |
| `powerup_repair.png` | 24x24 | power-up reparo |
| `explosion_0.png` ... `explosion_4.png` | 48x48 | 5 frames de explosão |

Qualquer imagem que você não colocar continua funcionando com o
placeholder gerado automaticamente — não precisa ter o pacote completo
para testar.

## O que está implementado (conforme GDD)

- Movimento 8 direções com clamp na tela, disparo com cadência de 0.25s
- 3 tipos de inimigo (scout, interceptor senoidal, cruiser atirador) com
  taxas de spawn ponderadas (60/25/15%)
- Power-ups (tiro duplo, escudo, reparo) com 15% de chance de drop
- Escalonamento de dificuldade a cada 30s (spawn -10%, velocidade +5%)
- Pontuação por abate + 10 pts/s de sobrevivência, high score salvo em
  `highscore.txt`
- HUD (HP em corações, score, high score, status de escudo)
- Fundo estelar parallax (2 camadas), partículas de propulsão, explosões
  animadas de 5 frames
- Estados MENU / PLAYING / PAUSED / GAMEOVER

## Observação

Não consegui rodar o jogo com uma janela real neste ambiente (sem acesso
a display/internet aqui), então validei a sintaxe e revisei a lógica
manualmente — mas roda em qualquer máquina com Python + Pygame
instalados normalmente. Se algo travar ao testar aí, me manda o erro que
eu ajusto na hora.
