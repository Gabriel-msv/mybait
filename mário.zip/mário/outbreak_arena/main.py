"""
Outbreak Arena - Top-Down Twin-Stick Shooter / Arena Survival
Implementado conforme GDD 2.

ASSETS:
Coloque os arquivos PNG na pasta assets/ com estes nomes exatos.
Se um arquivo não existir, o jogo desenha um placeholder colorido
no lugar, então ele SEMPRE roda, mesmo sem os PNGs.

    assets/
        player.png            (44x44) - sobrevivente (aponta p/ direita, será rotacionado)
        enemy_chaser.png       (36x36) - inimigo perseguidor
        enemy_tank.png         (52x52) - inimigo tanque
        weapon_pistol_icon.png (24x24) - ícone da pistola no HUD
        weapon_shotgun_icon.png(24x24) - ícone da escopeta no HUD
        weapon_rifle_icon.png  (24x24) - ícone do fuzil no HUD
        bullet.png             (10x4)  - projétil (será rotacionado)
        drop_ammo.png          (22x22) - caixa de munição
        drop_health.png        (22x22) - caixa de vida
        floor_tile.png         (64x64) - textura de chão (repetida em tile)
        crosshair.png          (28x28) - retícula de mira

Recomendo o pacote "Top-Down Shooter" ou "Zombie Shooter" da Kenney.nl
(licença CC0, gratuita) - renomeie os arquivos baixados para os nomes acima.

Como rodar:
    pip install pygame
    python main.py
"""

import os
import sys
import math
import random
import pygame

# ---------------------------------------------------------------------------
# CONFIGURAÇÃO GERAL
# ---------------------------------------------------------------------------

SCREEN_W, SCREEN_H = 900, 640
FPS = 60

ASSET_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")

BLACK = (10, 10, 12)
DARK = (28, 30, 34)
WHITE = (240, 240, 245)
RED = (220, 60, 60)
GREEN = (70, 200, 120)
BLUE = (70, 140, 230)
YELLOW = (240, 210, 80)
GRAY = (120, 120, 130)
ORANGE = (230, 150, 60)
PURPLE = (150, 90, 200)

MAP_MARGIN = 40  # borda sólida da arena

# ---------------------------------------------------------------------------
# CARREGAMENTO DE ASSETS COM FALLBACK
# ---------------------------------------------------------------------------


def load_image(filename, size, fallback_draw):
    path = os.path.join(ASSET_DIR, filename)
    surf = pygame.Surface(size, pygame.SRCALPHA)
    if os.path.isfile(path):
        try:
            img = pygame.image.load(path).convert_alpha()
            return pygame.transform.smoothscale(img, size)
        except Exception as e:
            print(f"[aviso] Falha ao carregar {filename}: {e}. Usando placeholder.")
    fallback_draw(surf, size)
    return surf


def _fb_player(surf, size):
    w, h = size
    # nave aponta para a direita (ângulo 0), pois será rotacionada conforme mouse
    pygame.draw.circle(surf, BLUE, (w // 2, h // 2), w // 2)
    pygame.draw.polygon(surf, WHITE, [(w * 0.55, h * 0.5), (w * 0.2, h * 0.25), (w * 0.2, h * 0.75)])


def _fb_enemy(color, shape="circle"):
    def draw(surf, size):
        w, h = size
        if shape == "circle":
            pygame.draw.circle(surf, color, (w // 2, h // 2), w // 2)
        else:
            pygame.draw.rect(surf, color, (2, 2, w - 4, h - 4), border_radius=6)
        pygame.draw.circle(surf, (30, 30, 30), (w // 2, h // 2), max(2, w // 10))
    return draw


def _fb_bullet(surf, size):
    w, h = size
    pygame.draw.rect(surf, YELLOW, (0, 0, w, h), border_radius=h // 2)


def _fb_drop(color, symbol):
    def draw(surf, size):
        w, h = size
        pygame.draw.rect(surf, color, (0, 0, w, h), border_radius=4)
        pygame.draw.rect(surf, WHITE, (0, 0, w, h), 2, border_radius=4)
    return draw


def _fb_crosshair(surf, size):
    w, h = size
    pygame.draw.circle(surf, WHITE, (w // 2, h // 2), w // 2 - 2, 2)
    pygame.draw.line(surf, WHITE, (w // 2, 0), (w // 2, 6), 2)
    pygame.draw.line(surf, WHITE, (w // 2, h - 6), (w // 2, h), 2)
    pygame.draw.line(surf, WHITE, (0, h // 2), (6, h // 2), 2)
    pygame.draw.line(surf, WHITE, (w - 6, h // 2), (w, h // 2), 2)


def _fb_floor_tile(surf, size):
    w, h = size
    surf.fill(DARK)
    pygame.draw.rect(surf, (36, 38, 44), (0, 0, w, h), 1)


class Assets:
    def __init__(self):
        self.player = load_image("player.png", (44, 44), _fb_player)
        self.enemy_chaser = load_image("enemy_chaser.png", (36, 36), _fb_enemy((90, 170, 90), "circle"))
        self.enemy_tank = load_image("enemy_tank.png", (52, 52), _fb_enemy((150, 90, 90), "square"))
        self.bullet = load_image("bullet.png", (10, 4), _fb_bullet)
        self.drop_ammo = load_image("drop_ammo.png", (22, 22), _fb_drop(ORANGE, "A"))
        self.drop_health = load_image("drop_health.png", (22, 22), _fb_drop(GREEN, "+"))
        self.floor_tile = load_image("floor_tile.png", (64, 64), _fb_floor_tile)
        self.crosshair = load_image("crosshair.png", (28, 28), _fb_crosshair)


# ---------------------------------------------------------------------------
# ARMAS (GDD 4.2)
# ---------------------------------------------------------------------------


class WeaponDef:
    def __init__(self, name, damage, cadence, mag, reserve, reload_time, spread_deg, pellets=1, pierce=False):
        self.name = name
        self.damage = damage
        self.cadence = cadence
        self.mag_size = mag
        self.reserve = reserve  # None = infinito
        self.reload_time = reload_time
        self.spread_deg = spread_deg
        self.pellets = pellets
        self.pierce = pierce  # projétil atravessa inimigos, atingindo todos no caminho


WEAPONS = {
    "pistol": WeaponDef("Pistola", 25, 0.3, 12, None, 1.2, 2),
    "shotgun": WeaponDef("Escopeta", 15, 0.8, 6, 36, 2.5, 15, pellets=5),
    "rifle": WeaponDef("Fuzil de Assalto", 18, 0.1, 30, 120, 1.8, 5),
    # arma do personagem Siqueira: escopeta rápida, 3 balas por disparo, 1 disparo/s, com dispersão
    "shotgun_siqueira": WeaponDef("Escopeta do Siqueira", 14, 1.0, 9, 45, 2.2, 12, pellets=3),
    # arma do personagem Ademir: revólver perfurante, atravessa e dana todos os inimigos no caminho
    "revolver_ademir": WeaponDef("Revólver do Ademir", 40, 0.55, 6, 30, 1.8, 1, pellets=1, pierce=True),
}
WEAPON_ORDER = ["pistol", "shotgun", "shotgun_siqueira", "revolver_ademir", "rifle"]

CHARACTERS = {
    "siqueira": {
        "label": "Siqueira",
        "desc": "Pistola + Escopeta rápida (3 balas/disparo, dispersão)",
        "weapon_order": ["pistol", "shotgun_siqueira"],
    },
    "ademir": {
        "label": "Ademir",
        "desc": "Revólver perfurante (atravessa inimigos) + Fuzil de Assalto",
        "weapon_order": ["revolver_ademir", "rifle"],
    },
}


class WeaponState:
    """Estado de munição/cooldown de uma arma equipada."""

    def __init__(self, weapon_def):
        self.wdef = weapon_def
        self.mag = weapon_def.mag_size
        self.reserve = weapon_def.reserve  # None = infinita
        self.fire_timer = 0.0
        self.reload_timer = 0.0
        self.reloading = False

    def can_fire(self):
        return not self.reloading and self.fire_timer <= 0 and self.mag > 0

    def start_reload(self):
        if self.reloading or self.mag == self.wdef.mag_size:
            return
        if self.reserve is not None and self.reserve <= 0:
            return
        self.reloading = True
        self.reload_timer = self.wdef.reload_time

    def update(self, dt):
        if self.fire_timer > 0:
            self.fire_timer -= dt
        if self.reloading:
            self.reload_timer -= dt
            if self.reload_timer <= 0:
                self.reloading = False
                needed = self.wdef.mag_size - self.mag
                if self.reserve is None:
                    self.mag = self.wdef.mag_size
                else:
                    take = min(needed, self.reserve)
                    self.mag += take
                    self.reserve -= take

    def fire(self):
        self.mag -= 1
        self.fire_timer = self.wdef.cadence
        if self.mag <= 0:
            self.start_reload()


# ---------------------------------------------------------------------------
# ENTIDADES
# ---------------------------------------------------------------------------


class Bullet(pygame.sprite.Sprite):
    SPEED = 700

    def __init__(self, image, pos, angle_deg, damage, pierce=False):
        super().__init__()
        self.base_image = image
        self.image = pygame.transform.rotate(image, angle_deg)
        self.rect = self.image.get_rect(center=pos)
        rad = math.radians(angle_deg)
        self.velocity = pygame.math.Vector2(math.cos(rad), -math.sin(rad)) * self.SPEED
        self.pos = pygame.math.Vector2(pos)
        self.damage = damage
        self.pierce = pierce
        self.hit_enemies = set()  # inimigos já atingidos por este projétil (evita dano repetido)

    def update(self, dt):
        self.pos += self.velocity * dt
        self.rect.center = (round(self.pos.x), round(self.pos.y))
        if not pygame.Rect(-20, -20, SCREEN_W + 40, SCREEN_H + 40).collidepoint(self.rect.center):
            self.kill()


class BloodMark:
    """Marca estática no chão (GDD 5, limite de 100)."""

    def __init__(self, pos):
        self.pos = pos
        self.radius = random.randint(3, 7)

    def draw(self, surf):
        pygame.draw.circle(surf, (90, 20, 20), self.pos, self.radius)


class DamageNumber:
    """Número de dano flutuante exibido ao acertar um inimigo."""

    LIFETIME = 0.6
    RISE_SPEED = 45

    def __init__(self, pos, amount, crit=False):
        self.pos = pygame.math.Vector2(pos)
        self.amount = amount
        self.age = 0.0
        self.crit = crit
        self.offset_x = random.uniform(-8, 8)

    def update(self, dt):
        self.age += dt
        self.pos.y -= self.RISE_SPEED * dt

    @property
    def alive(self):
        return self.age < self.LIFETIME

    @property
    def alpha(self):
        remain = 1 - (self.age / self.LIFETIME)
        return max(0, min(255, int(255 * remain)))


class DropItem(pygame.sprite.Sprite):
    def __init__(self, image, pos, kind, value):
        super().__init__()
        self.image = image
        self.rect = self.image.get_rect(center=pos)
        self.kind = kind  # "ammo" or "health"
        self.value = value

    def update(self, dt):
        pass


class Player(pygame.sprite.Sprite):
    SPEED = 220
    SPEED_RELOAD = 150
    MAX_HP = 100

    def __init__(self, assets, game, character="siqueira"):
        super().__init__()
        self.assets = assets
        self.game = game
        self.base_image = assets.player
        self.image = self.base_image
        self.rect = self.image.get_rect(center=(SCREEN_W // 2, SCREEN_H // 2))
        self.pos = pygame.math.Vector2(self.rect.center)
        self.angle = 0.0
        self.hp = self.MAX_HP

        self.character = character
        char_def = CHARACTERS.get(character, CHARACTERS["siqueira"])
        self.weapon_order = char_def["weapon_order"]
        self.weapons = {slot: WeaponState(WEAPONS[slot]) for slot in self.weapon_order}
        self.active_slot = self.weapon_order[0]
        self.flash_timer = 0.0

    @property
    def active_weapon(self):
        return self.weapons[self.active_slot]

    def switch_weapon(self, slot):
        if slot in self.weapons:
            self.active_slot = slot

    def pickup_weapon(self, slot_hint=None):
        """Ao trocar de arma via loot (não usado diretamente aqui, placeholder)."""
        pass

    def handle_input(self, dt, keys, mouse_pos, mouse_down):
        wstate = self.active_weapon
        reloading = wstate.reloading
        speed = self.SPEED_RELOAD if reloading else self.SPEED

        direction = pygame.math.Vector2(0, 0)
        if keys[pygame.K_a]:
            direction.x -= 1
        if keys[pygame.K_d]:
            direction.x += 1
        if keys[pygame.K_w]:
            direction.y -= 1
        if keys[pygame.K_s]:
            direction.y += 1
        if direction.length_squared() > 0:
            direction = direction.normalize()
        self.pos += direction * speed * dt

        bounds = pygame.Rect(
            MAP_MARGIN + self.rect.width // 2,
            MAP_MARGIN + self.rect.height // 2,
            SCREEN_W - 2 * MAP_MARGIN - self.rect.width,
            SCREEN_H - 2 * MAP_MARGIN - self.rect.height,
        )
        self.pos.x = max(bounds.left, min(bounds.right, self.pos.x))
        self.pos.y = max(bounds.top, min(bounds.bottom, self.pos.y))
        self.rect.center = (round(self.pos.x), round(self.pos.y))

        # mira matemática: vetor player -> mouse (GDD 4.1)
        mx, my = mouse_pos
        dx = mx - self.pos.x
        dy = my - self.pos.y
        self.angle = math.degrees(math.atan2(-dy, dx))
        self.image = pygame.transform.rotate(self.base_image, self.angle)
        self.rect = self.image.get_rect(center=self.rect.center)

        if self.flash_timer > 0:
            self.flash_timer -= dt

        wstate.update(dt)
        if mouse_down and wstate.can_fire():
            self.shoot()

    def shoot(self):
        wdef = self.active_weapon.wdef
        origin = self.pos
        for _ in range(wdef.pellets):
            spread = random.uniform(-wdef.spread_deg, wdef.spread_deg)
            angle = self.angle + spread
            b = Bullet(self.assets.bullet, origin, angle, wdef.damage, pierce=wdef.pierce)
            self.game.player_bullets.add(b)
            self.game.all_sprites.add(b)
        self.active_weapon.fire()
        self.flash_timer = 0.05
        if wdef.pellets > 1:
            self.game.screen_shake = 6.0

    def reload(self):
        self.active_weapon.start_reload()

    def take_damage(self, amount):
        self.hp -= amount
        if self.hp <= 0:
            self.hp = 0
            self.game.on_player_death()

    def heal(self, amount):
        self.hp = min(self.MAX_HP, self.hp + amount)

    def add_ammo(self, amount):
        wstate = self.active_weapon
        if wstate.reserve is not None:
            wstate.reserve += amount

    def draw(self, surf, offset=(0, 0)):
        rect = self.rect.move(offset)
        surf.blit(self.image, rect)


class Enemy(pygame.sprite.Sprite):
    TYPE_DATA = {
        "chaser": dict(hp=50, speed=120, dps=10, hit_dmg=0, contact=True),
        "tank": dict(hp=250, speed=70, dps=0, hit_dmg=25, contact=False),
    }

    def __init__(self, assets, game, kind, pos):
        super().__init__()
        self.assets = assets
        self.game = game
        self.kind = kind
        data = self.TYPE_DATA[kind]
        self.hp = data["hp"]
        self.speed = data["speed"]
        self.dps = data["dps"]
        self.hit_dmg = data["hit_dmg"]
        self.contact_continuous = data["contact"]

        image_map = {"chaser": assets.enemy_chaser, "tank": assets.enemy_tank}
        self.base_image = image_map[kind]
        self.image = self.base_image
        self.rect = self.image.get_rect(center=pos)
        self.pos = pygame.math.Vector2(pos)
        self.flash_timer = 0.0
        self.hit_cooldown = 0.0  # para dano de contato do tanque (por hit, não contínuo)

    def update(self, dt, player_pos, enemies_group):
        # 1-3: perseguição via vetor normalizado (GDD 4.3)
        to_player = pygame.math.Vector2(player_pos) - self.pos
        if to_player.length_squared() > 1:
            direction = to_player.normalize()
        else:
            direction = pygame.math.Vector2(0, 0)

        # 4: repulsão simples entre inimigos
        repulsion = pygame.math.Vector2(0, 0)
        for other in enemies_group:
            if other is self:
                continue
            diff = self.pos - other.pos
            dist = diff.length()
            min_dist = (self.rect.width + other.rect.width) / 2
            if 0 < dist < min_dist:
                repulsion += diff.normalize() * (min_dist - dist) * 4

        self.pos += direction * self.speed * dt + repulsion * dt
        self.rect.center = (round(self.pos.x), round(self.pos.y))

        if self.flash_timer > 0:
            self.flash_timer -= dt
            self.image = self._tinted_flash()
        else:
            self.image = self.base_image

        if self.hit_cooldown > 0:
            self.hit_cooldown -= dt

    def _tinted_flash(self):
        img = self.base_image.copy()
        overlay = pygame.Surface(img.get_size(), pygame.SRCALPHA)
        overlay.fill((255, 60, 60, 120))
        img.blit(overlay, (0, 0), special_flags=pygame.BLEND_RGBA_ADD)
        return img

    def take_damage(self, amount):
        self.hp -= amount
        self.flash_timer = 0.1
        return self.hp <= 0


class WaveManager:
    """Controla ondas e transições (GDD 4.4)."""

    def __init__(self, game):
        self.game = game
        self.wave = 0
        self.state = "intermission"
        self.intermission_timer = 2.0
        self.to_spawn = 0
        self.spawn_gap_timer = 0.0

    def start_next_wave(self):
        self.wave += 1
        self.to_spawn = 10 + self.wave * 5
        self.state = "spawning"
        self.spawn_gap_timer = 0.0

    def _spawn_point(self):
        # borda do mapa
        side = random.choice(["top", "bottom", "left", "right"])
        if side == "top":
            return (random.randint(MAP_MARGIN, SCREEN_W - MAP_MARGIN), MAP_MARGIN)
        if side == "bottom":
            return (random.randint(MAP_MARGIN, SCREEN_W - MAP_MARGIN), SCREEN_H - MAP_MARGIN)
        if side == "left":
            return (MAP_MARGIN, random.randint(MAP_MARGIN, SCREEN_H - MAP_MARGIN))
        return (SCREEN_W - MAP_MARGIN, random.randint(MAP_MARGIN, SCREEN_H - MAP_MARGIN))

    def update(self, dt):
        if self.state == "intermission":
            self.intermission_timer -= dt
            if self.intermission_timer <= 0:
                self.start_next_wave()
        elif self.state == "spawning":
            self.spawn_gap_timer -= dt
            if self.to_spawn > 0 and self.spawn_gap_timer <= 0:
                self.spawn_gap_timer = 0.4
                kind = "tank" if random.random() < 0.2 else "chaser"
                pos = self._spawn_point()
                enemy = Enemy(self.game.assets, self.game, kind, pos)
                self.game.enemies.add(enemy)
                self.to_spawn -= 1
            if self.to_spawn <= 0 and len(self.game.enemies) == 0:
                self.state = "intermission"
                self.intermission_timer = 5.0
                self.game.drop_supplies()


# ---------------------------------------------------------------------------
# JOGO
# ---------------------------------------------------------------------------


class Game:
    STATE_MENU = "MENU"
    STATE_PLAYING = "PLAYING"
    STATE_PAUSED = "PAUSED"
    STATE_GAMEOVER = "GAMEOVER"

    MAX_BLOOD_MARKS = 100

    def __init__(self):
        pygame.init()
        pygame.display.set_caption("Outbreak Arena")
        self.screen = pygame.display.set_mode((SCREEN_W, SCREEN_H))
        self.clock = pygame.time.Clock()
        self.assets = Assets()
        self.font_small = pygame.font.SysFont("consolas", 18)
        self.font_med = pygame.font.SysFont("consolas", 26, bold=True)
        self.font_big = pygame.font.SysFont("consolas", 46, bold=True)

        pygame.mouse.set_visible(False)

        self.selected_character = "siqueira"
        self.state = self.STATE_MENU
        self.screen_shake = 0.0
        self.blood_marks = []
        self.reset_run()

    def reset_run(self):
        self.all_sprites = pygame.sprite.Group()
        self.enemies = pygame.sprite.Group()
        self.player_bullets = pygame.sprite.Group()
        self.drops = pygame.sprite.Group()
        self.blood_marks = []
        self.damage_numbers = []

        self.player = Player(self.assets, self, self.selected_character)
        self.wave_manager = WaveManager(self)
        self.screen_shake = 0.0

    def on_player_death(self):
        self.state = self.STATE_GAMEOVER

    def drop_supplies(self):
        """Libera caixas de suplemento ao fim de cada onda (GDD 4.4)."""
        for _ in range(random.randint(2, 4)):
            x = random.randint(MAP_MARGIN + 20, SCREEN_W - MAP_MARGIN - 20)
            y = random.randint(MAP_MARGIN + 20, SCREEN_H - MAP_MARGIN - 20)
            kind = random.choice(["ammo", "health"])
            if kind == "ammo":
                d = DropItem(self.assets.drop_ammo, (x, y), "ammo", 24)
            else:
                d = DropItem(self.assets.drop_health, (x, y), "health", 25)
            self.drops.add(d)

    def add_blood_mark(self, pos):
        self.blood_marks.append(BloodMark(pos))
        if len(self.blood_marks) > self.MAX_BLOOD_MARKS:
            self.blood_marks.pop(0)

    def spawn_damage_number(self, pos, amount):
        self.damage_numbers.append(DamageNumber(pos, amount))

    # -- loop principal -----------------------------------------------
    def run(self):
        while True:
            dt = self.clock.tick(FPS) / 1000.0
            dt = min(dt, 1 / 30)
            self.handle_events()
            if self.state == self.STATE_PLAYING:
                self.update(dt)
            self.draw()
            pygame.display.flip()

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_p, pygame.K_ESCAPE):
                    if self.state == self.STATE_PLAYING:
                        self.state = self.STATE_PAUSED
                    elif self.state == self.STATE_PAUSED:
                        self.state = self.STATE_PLAYING
                if event.key == pygame.K_r and self.state == self.STATE_PLAYING:
                    self.player.reload()
                if event.key == pygame.K_1:
                    if self.state == self.STATE_MENU:
                        self.selected_character = "siqueira"
                    elif self.state == self.STATE_PLAYING:
                        self.player.switch_weapon(self.player.weapon_order[0])
                if event.key == pygame.K_2:
                    if self.state == self.STATE_MENU:
                        self.selected_character = "ademir"
                    elif self.state == self.STATE_PLAYING:
                        self.player.switch_weapon(self.player.weapon_order[1])
                if event.key == pygame.K_RETURN:
                    if self.state == self.STATE_MENU:
                        self.reset_run()
                        self.state = self.STATE_PLAYING
                    elif self.state == self.STATE_GAMEOVER:
                        self.state = self.STATE_MENU
            if event.type == pygame.MOUSEWHEEL and self.state == self.STATE_PLAYING:
                order = self.player.weapon_order
                available = [w for w in order if w in self.player.weapons]
                if available:
                    cur = available.index(self.player.active_slot)
                    cur = (cur + (1 if event.y < 0 else -1)) % len(available)
                    self.player.switch_weapon(available[cur])

    def update(self, dt):
        keys = pygame.key.get_pressed()
        mouse_pos = pygame.mouse.get_pos()
        mouse_down = pygame.mouse.get_pressed()[0]

        self.player.handle_input(dt, keys, mouse_pos, mouse_down)
        self.wave_manager.update(dt)
        self.enemies.update(dt, self.player.pos, self.enemies)
        self.player_bullets.update(dt)

        for dn in self.damage_numbers:
            dn.update(dt)
        self.damage_numbers = [dn for dn in self.damage_numbers if dn.alive]

        if self.screen_shake > 0:
            self.screen_shake = max(0.0, self.screen_shake - dt * 30)

        self._handle_collisions(dt)

    def _handle_collisions(self, dt):
        # tiro atinge inimigo (projéteis perfurantes atravessam e danam todos no caminho,
        # os demais são consumidos no primeiro inimigo atingido)
        for bullet in list(self.player_bullets):
            hit_enemies = pygame.sprite.spritecollide(bullet, self.enemies, False)
            if not hit_enemies:
                continue
            any_hit = False
            for enemy in hit_enemies:
                if bullet.pierce:
                    if enemy in bullet.hit_enemies:
                        continue
                    bullet.hit_enemies.add(enemy)
                any_hit = True
                dead = enemy.take_damage(bullet.damage)
                self.spawn_damage_number(enemy.rect.center, bullet.damage)
                self.add_blood_mark(enemy.rect.center)
                if dead:
                    enemy.kill()
                if not bullet.pierce:
                    break
            if any_hit and not bullet.pierce:
                bullet.kill()

        # contato inimigo -> jogador
        if self.state == self.STATE_PLAYING:
            for enemy in self.enemies:
                dist = enemy.pos.distance_to(self.player.pos)
                min_dist = (enemy.rect.width + self.player.rect.width) / 2
                if dist < min_dist:
                    if enemy.contact_continuous:
                        self.player.take_damage(enemy.dps * dt)
                    else:
                        if enemy.hit_cooldown <= 0:
                            self.player.take_damage(enemy.hit_dmg)
                            enemy.hit_cooldown = 0.6
                            self.screen_shake = 4.0

            # coleta de drops
            collected = pygame.sprite.spritecollide(self.player, self.drops, True)
            for d in collected:
                if d.kind == "ammo":
                    self.player.add_ammo(d.value)
                else:
                    self.player.heal(d.value)

    # -- desenho --------------------------------------------------------
    def _shake_offset(self):
        if self.screen_shake <= 0:
            return (0, 0)
        return (random.uniform(-1, 1) * self.screen_shake, random.uniform(-1, 1) * self.screen_shake)

    def draw(self):
        self.screen.fill(BLACK)
        offset = self._shake_offset()

        self._draw_floor(offset)

        if self.state == self.STATE_MENU:
            self.draw_menu()
        else:
            self.draw_playfield(offset)
            if self.state == self.STATE_PAUSED:
                self.draw_pause_overlay()
            elif self.state == self.STATE_GAMEOVER:
                self.draw_gameover_overlay()

        if self.state in (self.STATE_PLAYING, self.STATE_PAUSED):
            self._draw_crosshair()

    def _draw_floor(self, offset):
        tile = self.assets.floor_tile
        tw, th = tile.get_size()
        for y in range(0, SCREEN_H, th):
            for x in range(0, SCREEN_W, tw):
                self.screen.blit(tile, (x + offset[0], y + offset[1]))
        # borda da arena
        pygame.draw.rect(
            self.screen, (60, 60, 70),
            pygame.Rect(MAP_MARGIN + offset[0], MAP_MARGIN + offset[1],
                        SCREEN_W - 2 * MAP_MARGIN, SCREEN_H - 2 * MAP_MARGIN),
            4,
        )

    def draw_playfield(self, offset):
        for mark in self.blood_marks:
            pygame.draw.circle(
                self.screen, (90, 20, 20),
                (mark.pos[0] + offset[0], mark.pos[1] + offset[1]), mark.radius,
            )
        for d in self.drops:
            self.screen.blit(d.image, d.rect.move(offset))
        for enemy in self.enemies:
            self.screen.blit(enemy.image, enemy.rect.move(offset))
        for b in self.player_bullets:
            self.screen.blit(b.image, b.rect.move(offset))
        self.player.draw(self.screen, offset)
        self._draw_damage_numbers(offset)

        self.draw_hud()

    def _draw_damage_numbers(self, offset):
        for dn in self.damage_numbers:
            txt_surf = self.font_small.render(str(int(dn.amount)), True, YELLOW)
            txt_surf.set_alpha(dn.alpha)
            pos = (dn.pos.x + dn.offset_x + offset[0], dn.pos.y + offset[1])
            rect = txt_surf.get_rect(center=pos)
            self.screen.blit(txt_surf, rect)

    def _draw_crosshair(self):
        mx, my = pygame.mouse.get_pos()
        rect = self.assets.crosshair.get_rect(center=(mx, my))
        self.screen.blit(self.assets.crosshair, rect)

    def draw_hud(self):
        # barra de HP
        hp_ratio = self.player.hp / Player.MAX_HP
        bar_w, bar_h = 220, 18
        bar_rect = pygame.Rect(20, 20, bar_w, bar_h)
        pygame.draw.rect(self.screen, (50, 50, 55), bar_rect, border_radius=4)
        fill_color = GREEN if hp_ratio > 0.5 else (YELLOW if hp_ratio > 0.25 else RED)
        pygame.draw.rect(self.screen, fill_color, (bar_rect.x, bar_rect.y, int(bar_w * hp_ratio), bar_h), border_radius=4)
        pygame.draw.rect(self.screen, WHITE, bar_rect, 2, border_radius=4)
        hp_txt = self.font_small.render(f"HP {int(self.player.hp)}/{Player.MAX_HP}", True, WHITE)
        self.screen.blit(hp_txt, (bar_rect.x + 6, bar_rect.y - 2))

        wave_txt = self.font_med.render(f"ONDA: {self.wave_manager.wave:02d}", True, WHITE)
        self.screen.blit(wave_txt, (SCREEN_W - wave_txt.get_width() - 20, 18))

        wstate = self.player.active_weapon
        reserve_txt = "∞" if wstate.reserve is None else str(wstate.reserve)
        ammo_txt = self.font_med.render(
            f"{wstate.mag}/{reserve_txt} [{wstate.wdef.name.upper()}]", True, WHITE
        )
        self.screen.blit(ammo_txt, (20, 48))

        if wstate.reloading:
            progress = 1 - (wstate.reload_timer / wstate.wdef.reload_time)
            bar_rect2 = pygame.Rect(20, 80, 180, 10)
            pygame.draw.rect(self.screen, (50, 50, 55), bar_rect2, border_radius=3)
            pygame.draw.rect(self.screen, ORANGE, (bar_rect2.x, bar_rect2.y, int(180 * progress), 10), border_radius=3)
            txt = self.font_small.render("RECARREGANDO...", True, ORANGE)
            self.screen.blit(txt, (20, 92))

        if self.wave_manager.state == "intermission" and self.state == self.STATE_PLAYING:
            t = max(0, self.wave_manager.intermission_timer)
            txt = self.font_small.render(f"Próxima onda em {t:.1f}s", True, GRAY)
            self.screen.blit(txt, (SCREEN_W // 2 - txt.get_width() // 2, 20))

    def draw_menu(self):
        title = self.font_big.render("OUTBREAK ARENA", True, WHITE)
        self.screen.blit(title, (SCREEN_W // 2 - title.get_width() // 2, 150))

        pick_txt = self.font_med.render("Escolha seu sobrevivente", True, WHITE)
        self.screen.blit(pick_txt, (SCREEN_W // 2 - pick_txt.get_width() // 2, 230))

        card_w, card_h = 320, 110
        gap = 30
        total_w = card_w * 2 + gap
        start_x = SCREEN_W // 2 - total_w // 2
        y = 270
        order = ["siqueira", "ademir"]
        keys = ["1", "2"]
        for i, char_id in enumerate(order):
            cdef = CHARACTERS[char_id]
            x = start_x + i * (card_w + gap)
            rect = pygame.Rect(x, y, card_w, card_h)
            selected = self.selected_character == char_id
            bg = (60, 70, 90) if selected else (34, 36, 42)
            pygame.draw.rect(self.screen, bg, rect, border_radius=8)
            border_color = YELLOW if selected else GRAY
            pygame.draw.rect(self.screen, border_color, rect, 2, border_radius=8)

            name_txt = self.font_med.render(f"[{keys[i]}] {cdef['label']}", True, WHITE)
            self.screen.blit(name_txt, (rect.x + 14, rect.y + 12))
            desc_txt = self.font_small.render(cdef["desc"], True, GRAY)
            self.screen.blit(desc_txt, (rect.x + 14, rect.y + 52))

        sub = self.font_small.render(
            "WASD move · Mouse mira · Clique atira · R recarrega · 1/2/roda troca arma", True, GRAY
        )
        self.screen.blit(sub, (SCREEN_W // 2 - sub.get_width() // 2, y + card_h + 30))
        prompt = self.font_med.render("ENTER para começar", True, YELLOW)
        self.screen.blit(prompt, (SCREEN_W // 2 - prompt.get_width() // 2, y + card_h + 65))

    def draw_pause_overlay(self):
        overlay = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 150))
        self.screen.blit(overlay, (0, 0))
        txt = self.font_big.render("PAUSADO", True, WHITE)
        self.screen.blit(txt, (SCREEN_W // 2 - txt.get_width() // 2, SCREEN_H // 2 - 24))

    def draw_gameover_overlay(self):
        overlay = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        self.screen.blit(overlay, (0, 0))
        txt = self.font_big.render("GAME OVER", True, RED)
        self.screen.blit(txt, (SCREEN_W // 2 - txt.get_width() // 2, 240))
        wave_txt = self.font_med.render(f"Você sobreviveu até a onda {self.wave_manager.wave}", True, WHITE)
        self.screen.blit(wave_txt, (SCREEN_W // 2 - wave_txt.get_width() // 2, 300))
        prompt = self.font_small.render("ENTER para voltar ao menu", True, YELLOW)
        self.screen.blit(prompt, (SCREEN_W // 2 - prompt.get_width() // 2, 350))


if __name__ == "__main__":
    Game().run()
