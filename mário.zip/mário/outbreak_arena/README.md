# Outbreak Arena

Top-down twin-stick shooter / arena survival (GDD 2), em Python + Pygame.

## Como rodar

```bash
pip install pygame
python main.py
```

## Controles

- **WASD**: mover
- **Mouse**: mirar (o sobrevivente rotaciona na direção do cursor)
- **Clique esquerdo**: atirar
- **R**: recarregar
- **1 / 2** ou **roda do mouse**: trocar de arma (pistola / fuzil)
- **P / Esc**: pausar
- **Enter**: iniciar / reiniciar

## Imagens (assets/)

O jogo **já roda sem nenhuma imagem** — sem PNGs em `assets/`, ele desenha
placeholders coloridos automaticamente.

Para usar sprites de verdade, baixe um pacote gratuito (ex: **Kenney.nl**
→ "Top-Down Shooter" ou "Zombie Shooter", licença CC0) e coloque os
arquivos em `assets/` com estes nomes exatos:

| Arquivo | Tamanho sugerido | Uso |
|---|---|---|
| `player.png` | 44x44 | sobrevivente, deve apontar para a **direita** (é rotacionado em runtime) |
| `enemy_chaser.png` | 36x36 | perseguidor rápido |
| `enemy_tank.png` | 52x52 | inimigo tanque |
| `bullet.png` | 10x4 | projétil (rotacionado conforme direção do tiro) |
| `drop_ammo.png` | 22x22 | caixa de munição |
| `drop_health.png` | 22x22 | caixa de vida |
| `floor_tile.png` | 64x64 | textura de chão (repetida em grid) |
| `crosshair.png` | 28x28 | retícula de mira customizada |

Qualquer imagem que faltar continua funcionando com o placeholder
gerado automaticamente.

## O que está implementado (conforme GDD)

- Movimento vetorial 8 direções, velocidade reduzida durante recarga
- Mira e rotação do sprite via `atan2` na direção do mouse
- 3 armas com cadência, capacidade, dano e dispersão próprias (Pistola,
  Escopeta, Fuzil de Assalto) — a escopeta dispara 5 projéteis em leque
- Sistema de munição com pente/reserva e recarga com barra de progresso
- 2 tipos de inimigo (perseguidor com dano contínuo por contato, tanque
  com dano por hit) com IA de perseguição por vetor normalizado +
  repulsão simples entre inimigos para evitar sobreposição
- Sistema de ondas: quantidade = `10 + onda*5`, intermissão de 5s com
  drop de caixas de suprimento
- HUD (barra de HP colorida por faixa, munição, arma ativa, contador de
  onda, barra de recarga)
- Retícula de mira customizada, flash vermelho ao acertar inimigo,
  screen shake em disparos de escopeta e hits de tanque, marcas de
  sangue no chão (limitadas a 100)
- Estados MENU / PLAYING / PAUSED / GAMEOVER

## Observação

Mesma observação do Cosmic Vanguard: não consigo rodar com janela real
neste ambiente (sem acesso a display/internet aqui), então validei a
sintaxe e revisei a lógica manualmente. Roda normalmente em qualquer
máquina com Python + Pygame. Se der algum erro aí, me manda que eu
ajusto na hora.
